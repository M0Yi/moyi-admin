# Test 插件

这是一个用于测试和演示插件系统的示例插件。

## 核心文件说明

### Setup.php (极简化钩子类)

`addons/Test/Manager/Setup.php` 文件已被极简化，只保留四个核心生命周期钩子方法：

- `install()` - 插件安装钩子，只记录日志
- `enable()` - 插件启用钩子，只记录日志
- `disable()` - 插件禁用钩子，只记录日志
- `uninstall()` - 插件卸载钩子，只记录日志

**设计理念**:
1. **职责分离**: Setup.php 只负责生命周期钩子，实际业务逻辑由 AddonService 统一处理
2. **简化维护**: 减少代码复杂度，专注于日志记录
3. **统一管理**: 所有插件的菜单和权限都通过配置文件和 AddonService 统一管理
4. **扩展性**: 如需添加特定插件逻辑，可以在钩子方法中扩展

## 配置文件

### 插件配置 (config.php)

插件支持通过 `config.php` 文件进行配置，该文件包含了插件的所有配置选项。

### 菜单和权限配置 (Manager/menus_permissions.json)

插件的菜单和权限配置存储在 `Manager/menus_permissions.json` 文件中，在插件安装时会自动创建这些菜单和权限，并**真正插入到数据库**的 `admin_menus` 和 `admin_permissions` 表中。

#### JSON配置格式

### 支持分组的树形结构

插件的菜单和权限配置支持分组功能，可以创建树形结构的权限体系。

```json
{
  "_comment": "插件菜单和权限配置说明",
  "description": "此文件定义了插件的菜单和权限配置，支持分组功能",

  "permissions": [
    {
      "name": "权限组名称",
      "slug": "group.slug",
      "type": "menu",
      "icon": "fa fa-group-icon",
      "path": "/admin/group-path",
      "method": "GET",
      "description": "权限组描述",
      "sort": 1000,
      "status": 1,
      "children": [
        {
          "name": "子权限名称",
          "slug": "child.permission.slug",
          "type": "menu",
          "path": "/admin/child-path",
          "method": "GET",
          "description": "子权限描述",
          "sort": 1,
          "status": 1,
          "children": [
            {
              "name": "按钮权限",
              "slug": "button.permission",
              "type": "button",
              "path": "/admin/button-path",
              "method": "POST|PUT|DELETE",
              "description": "按钮操作权限",
              "sort": 1,
              "status": 1
            }
          ]
        }
      ]
    }
  ],

  "menus": [
    {
      "parent_id": 0,
      "name": "group",
      "title": "菜单组",
      "icon": "bi bi-collection",
      "path": "/admin/group",
      "component": null,
      "redirect": null,
      "type": "group",
      "target": "_self",
      "badge": null,
      "badge_type": null,
      "permission": null,
      "visible": 1,
      "status": 1,
      "sort": 1000,
      "cache": 1,
      "config": null,
      "remark": "菜单分组"
    },
    {
      "parent_id": 0,
      "parent_slug": "group",
      "name": "submenu",
      "title": "子菜单",
      "icon": "bi bi-menu-button",
      "path": "/admin/submenu",
      "component": "submenu/index",
      "redirect": null,
      "type": "menu",
      "target": "_self",
      "badge": null,
      "badge_type": null,
      "permission": "submenu.view",
      "visible": 1,
      "status": 1,
      "sort": 1,
      "cache": 1,
      "config": null,
      "remark": "子菜单项"
    }
  ]
}
```

#### 数据库操作说明

插件启用时，系统会：
1. 读取 `menus_permissions.json` 配置文件
2. 递归创建权限树到 `admin_permissions` 表
3. 递归创建菜单树到 `admin_menus` 表
4. 建立正确的父子关系

插件禁用时，系统会：
1. 更新相关权限的状态为禁用
2. 更新相关菜单的状态为禁用
3. **注意**: 不会删除记录，只会禁用状态

#### 配置字段说明

**权限字段** (对应 `admin_permissions` 表):

**必需字段**:
- `name`: 权限显示名称
- `slug`: 权限唯一标识符 (唯一键)
- `path`: 路由路径
- `description`: 权限描述

**可选字段** (不指定将使用数据库默认值):
- `type`: 权限类型 (默认: `menu`)
- `method`: HTTP请求方法 (默认: `*`, 注意字段长度限制为10字符)
- `icon`: 图标
- `component`: 组件路径
- `status`: 权限状态 (默认: `1`)
- `sort`: 权限排序权重 (默认: `0`)

**注意**: 为避免数据库字段长度限制，`method` 字段应谨慎使用。建议不指定此字段，让系统使用默认值 `*`。

**菜单字段** (对应 `admin_menus` 表):
- `name`: 菜单唯一标识符 (英文，用于系统识别)
- `title`: 菜单显示名称 (中文，用于界面显示)
- `type`: 菜单类型 (`menu`/`group`/`link`/`divider`)
- `icon`: 菜单图标样式类名
- `path`: 路由路径 (注意：后端菜单路径不应包含 `/admin` 前缀，如 `/test` 而不是 `/admin/test`)
- `component`: 组件路径
- `permission`: 关联权限标识符
- `visible`: 是否可见 (1=可见, 0=隐藏)
- `status`: 菜单状态 (1=启用, 0=禁用)
- `sort`: 菜单排序权重
- `cache`: 是否缓存 (1=缓存, 0=不缓存)

**路径配置注意事项**:
- 菜单路径应该直接使用路由路径，不包含 `/admin` 前缀
- 例如：系统管理菜单使用 `/system`，用户管理使用 `/system/users`
- 插件菜单也应遵循相同规则，如 `/test`、`/test/demo`

### 配置格式

配置文件使用 PHP 数组格式，支持：
- 布尔值、字符串、数字
- 嵌套数组
- 注释说明

### 配置项说明

#### 基本配置
```php
'enabled' => true,  // 是否启用插件
```

#### 功能配置
```php
'test' => [
    'debug_mode' => false,    // 调试模式
    'max_items' => 100,       // 最大项目数
    'timeout' => 30,          // 超时时间（秒）
],

'demo' => [
    'show_examples' => true,  // 显示示例
    'auto_refresh' => false,  // 自动刷新
    'refresh_interval' => 5000, // 刷新间隔（毫秒）
],
```

#### 显示配置
```php
'display' => [
    'theme' => 'default',     // 主题
    'language' => 'zh_CN',    // 语言
    'show_tooltips' => true,  // 显示提示
],
```

#### 高级配置
```php
'cache' => [
    'enabled' => true,        // 启用缓存
    'ttl' => 3600,           // 缓存时间（秒）
    'driver' => 'file',      // 缓存驱动
],

'logging' => [
    'enabled' => false,      // 启用日志
    'level' => 'info',       // 日志级别
    'max_files' => 7,        // 最大日志文件数
],
```

## 使用方法

### 1. 修改配置

#### 方法一：直接编辑文件
直接编辑 `config.php` 文件来修改配置。

#### 方法二：通过代码修改（推荐）
```php
$addonService = make(\App\Service\Admin\AddonService::class);

// 修改单个配置项（保持原有格式）
$result = $addonService->updateAddonConfigValue('test', 'enabled', false);

// 修改整个配置
$newConfig = [
    'enabled' => true,
    'test' => ['debug_mode' => true]
];
$addonService->setAddonConfig('test', $newConfig, true); // true表示保持格式
```

#### 方法三：通过插件管理界面
在插件管理页面中点击"开启"或"关闭"按钮，会自动更新 `config.php` 中的 `enabled` 状态。

### 2. 在代码中读取配置

```php
// 获取插件配置
$addonService = make(\App\Service\Admin\AddonService::class);
$config = $addonService->getAddonConfig('test');

// 读取特定配置项
$enabled = $config['enabled'] ?? false;
$debugMode = $config['test']['debug_mode'] ?? false;
$theme = $config['display']['theme'] ?? 'default';
```

### 3. 插件启用状态管理

插件的启用状态会同步保存在两个地方：
1. **系统配置**：`storage/addon_config.php`（全局插件状态）
2. **插件配置**：`addons/Test/config.php`（插件自己的enabled状态）

```php
// 检查插件是否启用
$isEnabled = $addonService->isAddonEnabled('test');

// 启用插件
$addonService->enableAddon('test');

// 禁用插件
$addonService->disableAddon('test');
```

## 路由加载机制

插件的路由只有在满足以下条件时才会被加载：

1. **插件启用状态**：`config.php` 中的 `enabled` 必须为 `true`
2. **路由文件存在**：`routes.php` 文件必须存在
3. **插件目录有效**：插件目录结构正确

### 路由加载流程

1. 系统启动时，`RouteLoader` 扫描 `addons/` 目录
2. 对每个插件目录，检查 `config.php` 中的 `enabled` 状态
3. 只有启用的插件才会加载 `routes.php` 文件
4. 禁用的插件路由不会被注册到系统中

### 动态控制

通过插件管理界面可以实时控制插件状态：

```php
// 启用插件（会自动执行安装并加载路由）
$addonService->enableAddon('test');

// 禁用插件（会自动清理文件并卸载路由）
$addonService->disableAddon('test');
```

#### 启用即安装

**重要**：插件的启用操作会自动包含安装过程，即：
- 点击"启用"按钮时，系统会首先执行插件资源的安装和部署
- 只有安装成功后，插件才会真正被启用
- 启用的插件会自动加载路由配置

#### 禁用即清理

**重要**：插件的禁用操作会自动包含清理过程，即：
- 点击"禁用"按钮时，系统会清理插件安装时部署的所有文件和目录
- 插件路由自动卸载，不再可用
- 提升系统性能和安全性

禁用插件后，其路由将不再可用，所有相关文件将被清理。

## 资源文件管理

### assets.json 配置文件

`Manager/assets.json` 文件定义了插件安装时需要复制的文件和目录映射关系。

#### 配置格式

```json
{
  "directories": {
    "插件内目录路径": "目标目录路径"
  },
  "files": {
    "插件内文件路径": "目标文件路径"
  }
}
```

#### 示例配置

```json
{
  "directories": {
    "View/admin/test": "storage/view/admin/test",
    "Public/js/test": "public/js/test"
  },
  "files": {
    "Public/js/test.js": "public/js/test.js"
  }
}
```

#### 配置说明

- **directories**: 定义需要复制的目录，键为插件内的相对路径，值为系统中的绝对路径
- **files**: 定义需要复制的单个文件，键为插件内的相对路径，值为系统中的绝对路径
- 路径支持相对路径（相对于插件根目录）和绝对路径（相对于项目根目录）

#### 资源部署流程

插件安装会在启用时自动执行：

1. 用户点击"启用"按钮
2. 插件管理器读取 `Manager/assets.json` 配置
3. 根据配置创建目标目录
4. 复制目录和文件到指定位置
5. 更新插件配置文件中的 `enabled` 状态为 `true`
6. 插件路由自动加载

**注意**：不再需要单独的安装步骤，启用即完成安装。

## 文件结构

```
addons/Test/
├── config.php          # 插件配置文件
├── info.php           # 插件信息文件
├── Manager/
│   ├── assets.json     # 插件资源文件映射配置
│   └── Setup.php       # 插件安装和设置逻辑
├── routes.php         # 路由配置
├── Controller/        # 控制器
├── View/              # 视图文件
├── Public/            # 公共资源
└── Manager/           # 管理器
```

## 注意事项

1. 配置文件修改后可能需要重启应用或刷新缓存
2. 布尔值请使用 `true`/`false`，不要使用字符串
3. 数组支持嵌套，但不要创建循环引用
4. 配置文件应具有适当的权限，确保Web服务器可以读取但不能修改