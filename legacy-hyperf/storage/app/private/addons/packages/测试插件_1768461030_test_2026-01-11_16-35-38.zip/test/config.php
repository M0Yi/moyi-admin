<?php

/**
 * Test 插件配置文件
 *
 * 插件配置项定义，参考CRUD配置字段结构
 *
 * 列宽(col)属性说明:
 * - col-12 或 不设置: 独占一行
 * - col-md-6: 占一半宽度，可并排两个字段
 * - col-md-4: 占1/3宽度，可并排三个字段
 * - col-md-8: 占2/3宽度
 * - col-md-3: 占1/4宽度，可并排四个字段
 *
 * 支持响应式: col-md-6 lg-4 表示中等屏幕占一半，大屏幕占1/3
 */

return [
    /**
     * 是否启用插件
     * true: 启用插件功能
     * false: 禁用插件功能
     */
    'enabled' => false,

    /**
     * 插件配置项
     * 字段格式遵循 UniversalFormRenderer 标准规范
     *
     * 基础字段：
     * - name: 字段名（必需）
     * - label: 显示标签（必需）
     * - type: 字段类型（必需）
     * - required: 是否必填（可选，默认false）
     * - placeholder: 占位符（可选）
     * - help: 帮助文本（可选）
     * - col: 列宽类名（可选，默认'col-12'）
     * - value: 默认值（可选）
     * - options: 选项数组（select/radio/checkbox需要）
     * - multiple: 多选属性（select/checkbox可选）
     * - accept: 文件类型限制（file/image可选）
     * - step: 数字步长（number可选）
     * - on_value/off_value: 开关值（switch可选）
     */
    'configs' => [
        [
            'name' => 'test_text',
            'label' => '测试文本',
            'type' => 'text',
            'value' => '默认文本值',
            'help' => '用于测试的文本配置项',
            'col' => 'col-md-6',
        ],
        [
            'name' => 'test_number',
            'label' => '测试数字',
            'type' => 'number',
            'value' => 100,
            'help' => '用于测试的数字配置项',
            'col' => 'col-md-6',
        ],
        [
            'name' => 'test_switch',
            'label' => '测试开关',
            'type' => 'switch',
            'value' => true,
            'help' => '用于测试的开关配置项',
            'on_value' => 1,
            'off_value' => 0,
            'col' => 'col-md-4',
        ],
        [
            'name' => 'test_select',
            'label' => '测试选择',
            'type' => 'select',
            'value' => 'option1',
            'options' => [
                'option1' => '选项1',
                'option2' => '选项2',
                'option3' => '选项3',
            ],
            'help' => '用于测试的选择配置项',
            'col' => 'col-md-8',
        ],
        [
            'name' => 'test_textarea',
            'label' => '测试文本域',
            'type' => 'textarea',
            'value' => '默认的多行文本内容',
            'help' => '用于测试的文本域配置项',
            'col' => 'col-12',
        ],
        [
            'name' => 'test_date',
            'label' => '测试日期',
            'type' => 'date',
            'value' => '2024-01-01',
            'help' => '用于测试的日期配置项',
            'col' => 'col-md-6',
        ],
        [
            'name' => 'test_radio',
            'label' => '测试单选',
            'type' => 'radio',
            'value' => 'option1',
            'options' => [
                'option1' => '选项1',
                'option2' => '选项2',
                'option3' => '选项3',
            ],
            'help' => '用于测试的单选按钮组配置项',
            'col' => 'col-md-6',
        ],
        [
            'name' => 'test_checkbox',
            'label' => '测试多选',
            'type' => 'checkbox',
            'value' => ['option1', 'option3'],
            'options' => [
                'option1' => '选项1',
                'option2' => '选项2',
                'option3' => '选项3',
                'option4' => '选项4',
            ],
            'help' => '用于测试的多选复选框配置项',
            'multiple' => true,
            'col' => 'col-12',
        ],
        [
            'name' => 'test_multi_select',
            'label' => '测试多选下拉',
            'type' => 'select',
            'value' => ['option1', 'option3'],
            'options' => [
                'option1' => '选项1',
                'option2' => '选项2',
                'option3' => '选项3',
                'option4' => '选项4',
            ],
            'help' => '用于测试的多选下拉框配置项',
            'multiple' => true,
            'col' => 'col-md-8',
        ],
        [
            'name' => 'test_file',
            'label' => '测试文件上传',
            'type' => 'file',
            'value' => '',
            'help' => '用于测试的文件上传配置项',
            'col' => 'col-md-6',
        ],
        [
            'name' => 'test_image',
            'label' => '测试图片上传',
            'type' => 'image',
            'value' => '',
            'help' => '用于测试的图片上传配置项',
            'accept' => 'image/*',
            'col' => 'col-md-6',
        ],
        [
            'name' => 'test_color',
            'label' => '测试颜色选择器',
            'type' => 'color',
            'value' => '#007bff',
            'help' => '用于测试的颜色选择器配置项',
            'col' => 'col-md-6 col-lg-4',
        ],
        [
            'name' => 'test_icon',
            'label' => '测试图标选择器',
            'type' => 'icon',
            'value' => 'bi bi-house',
            'help' => '用于测试的图标选择器配置项，支持 Bootstrap 5 Icons',
            'col' => 'col-md-6',
            'icon_set' => 'bootstrap5', // 可选：bootstrap5, fontawesome, material, custom
            'options' => [
                // 如果不设置options，会使用默认的图标集
                'bi bi-house' => 'bi bi-house - 首页',
                'bi bi-person' => 'bi bi-person - 用户',
                'bi bi-gear' => 'bi bi-gear - 设置',
                'bi bi-search' => 'bi bi-search - 搜索',
                'bi bi-pencil' => 'bi bi-pencil - 编辑',
                'bi bi-trash' => 'bi bi-trash - 删除',
                'bi bi-floppy' => 'bi bi-floppy - 保存',
                'bi bi-plus-circle' => 'bi bi-plus-circle - 添加',
            ],
        ],
        [
            'name' => 'test_rich_text',
            'label' => '测试富文本编辑器',
            'type' => 'rich_text',
            'value' => '<p>默认的富文本内容</p>',
            'help' => '用于测试的富文本编辑器配置项',
            'col' => 'col-12',
        ],
    ],
];
