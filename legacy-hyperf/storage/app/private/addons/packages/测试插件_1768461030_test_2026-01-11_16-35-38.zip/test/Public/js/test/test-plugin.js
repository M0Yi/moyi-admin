// 测试插件专用 JavaScript 文件
// 用于演示插件如何添加自定义的 JavaScript 功能

console.log('Test Plugin JavaScript loaded successfully!');

// 插件相关的工具函数
window.TestPlugin = {
    // 显示插件信息
    showInfo: function() {
        alert('Test Plugin v1.0.0\n这是一个测试插件的演示文件');
    },

    // 测试 AJAX 调用
    testAjax: function() {
        fetch('/test/public/ping')
            .then(response => response.json())
            .then(data => {
                console.log('Test Plugin AJAX Response:', data);
                alert('AJAX 测试成功！响应：' + JSON.stringify(data, null, 2));
            })
            .catch(error => {
                console.error('AJAX Error:', error);
                alert('AJAX 测试失败：' + error.message);
            });
    },

    // 初始化插件功能
    init: function() {
        console.log('Test Plugin initialized');

        // 绑定事件监听器（如果页面上有相关元素）
        const testButton = document.getElementById('test-plugin-button');
        if (testButton) {
            testButton.addEventListener('click', function() {
                window.TestPlugin.showInfo();
            });
        }
    }
};

// 页面加载完成后自动初始化
document.addEventListener('DOMContentLoaded', function() {
    window.TestPlugin.init();
});

