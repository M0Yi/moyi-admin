<?php

declare(strict_types=1);

/**
 * 测试控制器路由定义
 *
 * 此文件定义了 App\Controller\Admin\TestController 的所有路由
 * 通过动态路由加载器自动加载，无需手动引入
 */

use Hyperf\HttpServer\Router\Router;

/**
 * 测试控制器路由组
 *
 * 路径模式：/admin/{adminPath}/test/*
 * 中间件：需要管理员认证和权限验证
 */
Router::addGroup('/admin/{adminPath:[a-zA-Z0-9\-_]+}/test', function () {
    // ========================================
    // 测试页面路由
    // ========================================

    /**
     * 测试首页
     * GET /admin/{adminPath}/test
     */
    Router::get('', 'Addons\Test\Controller\Admin\TestController@index');

    /**
     * 测试演示页面
     * GET /admin/{adminPath}/test/demo
     */
    Router::get('/demo', 'Addons\Test\Controller\Admin\TestController@demo');

    /**
     * 测试 API 接口
     * GET /admin/{adminPath}/test/api
     */
    Router::get('/api', 'Addons\Test\Controller\Admin\TestController@api');

    /**
     * 测试数据提交接口
     * POST /admin/{adminPath}/test/submit
     */
    Router::post('/submit', 'Addons\Test\Controller\Admin\TestController@submit');

}, [
    // 应用中间件
    'middleware' => [
        \App\Middleware\AdminAuthMiddleware::class,      // 管理员认证
        \App\Middleware\PermissionMiddleware::class,     // 权限验证
        \App\Middleware\OperationLogMiddleware::class,   // 操作日志
        \App\Middleware\InterceptLogMiddleware::class,   // 拦截日志
    ]
]);

/**
 * 公开的测试路由（无需登录）
 * 主要用于开发调试
 */
Router::addGroup('/test/public', function () {
    /**
     * 公开测试接口
     * GET /test/public/ping
     */
    Router::get('/ping', function () {
        return [
            'code' => 200,
            'message' => 'Test route loaded successfully',
            'timestamp' => time(),
            'source' => 'dynamic route loader'
        ];
    });

    /**
     * 健康检查接口
     * GET /test/public/health
     */
    Router::get('/health', function () {
        return [
            'status' => 'ok',
            'service' => 'test-routes',
            'version' => '1.0.0',
            'timestamp' => date('c')
        ];
    });
});
