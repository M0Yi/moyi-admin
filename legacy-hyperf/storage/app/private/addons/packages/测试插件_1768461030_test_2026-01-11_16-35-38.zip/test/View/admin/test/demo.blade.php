@extends('admin.layouts.admin')

@section('title', $title ?? '测试演示页面')
<!-- 侧边栏 -->
@push('admin_sidebar')
    @include('admin.components.sidebar')
@endpush
<!-- 顶栏 -->
@push('admin_navbar')
    @include('admin.components.navbar')
@endpush

@section('content')
<div class="container-fluid py-4">
    <!-- 页面标题 -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-1">{{ $title ?? '测试演示页面' }}</h4>
                    <p class="text-muted mb-0">展示各种组件和功能的测试页面</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="/admin/admin/test" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-1"></i>返回测试首页
                    </a>
                    <a href="/admin/admin/dashboard" class="btn btn-primary">
                        <i class="fas fa-tachometer-alt me-1"></i>返回仪表盘
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- 统计卡片 -->
    <div class="row mb-4">
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-muted mb-1">总用户数</h6>
                            <h4 class="mb-0">{{ $testData['stats']['total_users'] }}</h4>
                        </div>
                        <div class="text-primary">
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-muted mb-1">活跃用户</h6>
                            <h4 class="mb-0 text-success">{{ $testData['stats']['active_users'] }}</h4>
                        </div>
                        <div class="text-success">
                            <i class="fas fa-user-check fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-muted mb-1">非活跃用户</h6>
                            <h4 class="mb-0 text-warning">{{ $testData['stats']['inactive_users'] }}</h4>
                        </div>
                        <div class="text-warning">
                            <i class="fas fa-user-times fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-muted mb-1">当前时间</h6>
                            <h6 class="mb-0">{{ $currentTime }}</h6>
                        </div>
                        <div class="text-info">
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 组件演示 -->
    <div class="row">
        <!-- 表格演示 -->
        <div class="col-lg-8 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent">
                    <h6 class="mb-0">
                        <i class="fas fa-table me-2"></i>用户数据表格
                    </h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>姓名</th>
                                    <th>邮箱</th>
                                    <th>状态</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($testData['users'] as $user)
                                <tr>
                                    <td>{{ $user['id'] }}</td>
                                    <td>{{ $user['name'] }}</td>
                                    <td>{{ $user['email'] }}</td>
                                    <td>
                                        @if($user['status'] == 1)
                                            <span class="badge bg-success">活跃</span>
                                        @else
                                            <span class="badge bg-secondary">非活跃</span>
                                        @endif
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary me-1">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning me-1">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- 表单演示 -->
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent">
                    <h6 class="mb-0">
                        <i class="fas fa-edit me-2"></i>表单组件演示
                    </h6>
                </div>
                <div class="card-body">
                    <form>
                        <div class="mb-3">
                            <label class="form-label">用户名</label>
                            <input type="text" class="form-control" placeholder="请输入用户名">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">邮箱</label>
                            <input type="email" class="form-control" placeholder="请输入邮箱">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">状态</label>
                            <select class="form-select">
                                <option value="1">活跃</option>
                                <option value="0">非活跃</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="agree">
                                <label class="form-check-label" for="agree">
                                    同意条款
                                </label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-save me-1"></i>提交
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- 按钮和警告演示 -->
    <div class="row">
        <div class="col-12 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent">
                    <h6 class="mb-0">
                        <i class="fas fa-palette me-2"></i>按钮和警告组件
                    </h6>
                </div>
                <div class="card-body">
                    <!-- 按钮组 -->
                    <div class="mb-4">
                        <h6>按钮样式</h6>
                        <div class="d-flex flex-wrap gap-2">
                            <button class="btn btn-primary">主要按钮</button>
                            <button class="btn btn-secondary">次要按钮</button>
                            <button class="btn btn-success">成功按钮</button>
                            <button class="btn btn-danger">危险按钮</button>
                            <button class="btn btn-warning">警告按钮</button>
                            <button class="btn btn-info">信息按钮</button>
                            <button class="btn btn-light">浅色按钮</button>
                            <button class="btn btn-dark">深色按钮</button>
                        </div>
                    </div>

                    <!-- 轮廓按钮 -->
                    <div class="mb-4">
                        <h6>轮廓按钮</h6>
                        <div class="d-flex flex-wrap gap-2">
                            <button class="btn btn-outline-primary">主要</button>
                            <button class="btn btn-outline-secondary">次要</button>
                            <button class="btn btn-outline-success">成功</button>
                            <button class="btn btn-outline-danger">危险</button>
                        </div>
                    </div>

                    <!-- 警告组件 -->
                    <div class="mb-4">
                        <h6>警告消息</h6>
                        <div class="alert alert-primary" role="alert">
                            <i class="fas fa-info-circle me-2"></i>这是一个主要信息的警告。
                        </div>
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-check-circle me-2"></i>操作成功！
                        </div>
                        <div class="alert alert-warning" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>请注意这个警告。
                        </div>
                        <div class="alert alert-danger" role="alert">
                            <i class="fas fa-times-circle me-2"></i>发生错误！
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 进度条和徽章 -->
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent">
                    <h6 class="mb-0">
                        <i class="fas fa-chart-line me-2"></i>进度条
                    </h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">完成进度 (75%)</label>
                        <div class="progress">
                            <div class="progress-bar bg-success" style="width: 75%"></div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">加载进度 (50%)</label>
                        <div class="progress">
                            <div class="progress-bar bg-info progress-bar-striped" style="width: 50%"></div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">错误进度 (25%)</label>
                        <div class="progress">
                            <div class="progress-bar bg-danger" style="width: 25%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent">
                    <h6 class="mb-0">
                        <i class="fas fa-tags me-2"></i>徽章和标签
                    </h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6>状态徽章</h6>
                        <span class="badge bg-primary me-2">主要</span>
                        <span class="badge bg-success me-2">成功</span>
                        <span class="badge bg-danger me-2">危险</span>
                        <span class="badge bg-warning me-2">警告</span>
                        <span class="badge bg-info me-2">信息</span>
                        <span class="badge bg-secondary">次要</span>
                    </div>
                    <div class="mb-3">
                        <h6>胶囊徽章</h6>
                        <span class="badge rounded-pill bg-primary me-2">胶囊样式</span>
                        <span class="badge rounded-pill bg-success me-2">成功</span>
                        <span class="badge rounded-pill bg-light text-dark">浅色</span>
                    </div>
                    <div class="mb-3">
                        <h6>带数字的徽章</h6>
                        <button class="btn btn-primary position-relative">
                            消息
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                99+
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 模态框触发按钮 -->
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent">
                    <h6 class="mb-0">
                        <i class="fas fa-window-restore me-2"></i>模态框演示
                    </h6>
                </div>
                <div class="card-body">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#demoModal">
                        <i class="fas fa-external-link-alt me-1"></i>打开演示模态框
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 演示模态框 -->
<div class="modal fade" id="demoModal" tabindex="-1" aria-labelledby="demoModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="demoModalLabel">演示模态框</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="关闭"></button>
            </div>
            <div class="modal-body">
                <p>这是一个演示模态框，用于展示模态框组件的功能。</p>
                <p>当前时间：{{ $currentTime }}</p>
                <p>这个页面展示了以下组件：</p>
                <ul>
                    <li>统计卡片</li>
                    <li>数据表格</li>
                    <li>表单组件</li>
                    <li>各种按钮样式</li>
                    <li>警告消息</li>
                    <li>进度条</li>
                    <li>徽章和标签</li>
                    <li>模态框</li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                <button type="button" class="btn btn-primary">确定</button>
            </div>
        </div>
    </div>
</div>
@endsection
