<?php

declare(strict_types=1);

namespace Addons\Test\Controller\Admin;

use App\Controller\AbstractController;

/**
 * 测试控制器
 *
 * 路由通过动态路由加载器自动加载，无需手动配置
 * 路由文件位置：app/Routes/test.php
 */
class TestController extends AbstractController
{
    /**
     * 测试首页
     */
    public function index()
    {
        return $this->renderAdmin('admin.test.index', [
            'adminMenuEnabled' => true,
        ]);
    }

    /**
     * 测试演示页面
     * 展示各种组件和功能的测试页面
     */
    public function demo()
    {
        return $this->renderAdmin('admin.test.demo', [
            'title' => '测试演示页面',
            'adminMenuEnabled' => true,
            'currentTime' => date('Y-m-d H:i:s'),
            'testData' => [
                'users' => [
                    ['id' => 1, 'name' => '张三', 'email' => 'zhangsan@example.com', 'status' => 1],
                    ['id' => 2, 'name' => '李四', 'email' => 'lisi@example.com', 'status' => 0],
                    ['id' => 3, 'name' => '王五', 'email' => 'wangwu@example.com', 'status' => 1],
                ],
                'stats' => [
                    'total_users' => 150,
                    'active_users' => 120,
                    'inactive_users' => 30,
                ]
            ]
        ]);
    }

    /**
     * 测试 API 接口
     * 返回 JSON 数据
     */
    public function api()
    {
        return $this->response->json([
            'code' => 200,
            'message' => '动态路由加载测试成功',
            'data' => [
                'timestamp' => time(),
                'method' => 'GET',
                'route' => 'test/api',
                'source' => 'dynamic route loader'
            ]
        ]);
    }

    /**
     * 测试 POST 接口
     */
    public function submit()
    {
        $data = $this->request->all();

        return $this->response->json([
            'code' => 200,
            'message' => '数据提交成功',
            'data' => $data,
            'timestamp' => time(),
            'source' => 'dynamic route loader'
        ]);
    }
}
