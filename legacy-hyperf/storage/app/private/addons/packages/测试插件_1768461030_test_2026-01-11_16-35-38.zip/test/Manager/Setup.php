<?php

declare(strict_types=1);

namespace Addons\Test\Manager;

/**
 * 测试插件管理器
 *
 * 插件生命周期钩子，只记录日志
 */
class Setup
{
    /**
     * 插件标识
     */
    public const PLUGIN_ID = 'test';

    /**
     * 插件名称
     */
    public const PLUGIN_NAME = '测试插件';

    /**
     * 插件版本
     */
    public const PLUGIN_VERSION = '1.0.0';

    /**
     * 安装插件钩子
     *
     * @return bool
     */
    public function install(): bool
    {
        logger()->info("[插件钩子] " . self::PLUGIN_NAME . " 开始安装");
        logger()->info("[插件钩子] " . self::PLUGIN_NAME . " 安装完成，版本: " . self::PLUGIN_VERSION);
        return true;
    }

    /**
     * 启用插件钩子
     *
     * @return bool
     */
    public function enable(): bool
    {
        logger()->info("[插件钩子] " . self::PLUGIN_NAME . " 开始启用");
        logger()->info("[插件钩子] " . self::PLUGIN_NAME . " 启用完成");
        return true;
    }

    /**
     * 禁用插件钩子
     *
     * @return bool
     */
    public function disable(): bool
    {
        logger()->info("[插件钩子] " . self::PLUGIN_NAME . " 开始禁用");
        logger()->info("[插件钩子] " . self::PLUGIN_NAME . " 禁用完成");
        return true;
    }

    /**
     * 卸载插件钩子
     *
     * @return bool
     */
    public function uninstall(): bool
    {
        logger()->info("[插件钩子] " . self::PLUGIN_NAME . " 开始卸载");
        logger()->info("[插件钩子] " . self::PLUGIN_NAME . " 卸载完成");
        return true;
    }
}